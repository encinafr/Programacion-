﻿using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Xml;
using System.Xml.Serialization;
using System.Data;//Requerido para base de datos



namespace sqlPrueba
{
    public class Televisor
    {
        public int id;
        public string marca;
        public double precio;
        public int pulgadas;
        public string pais;

        public Televisor()
        {

        }

        public Televisor(int id, string marca, double precio, int pulg, string rancho)
        {
            this.id = id;
            this.marca = marca;
            this.precio = precio;
            this.pulgadas = pulg;
            this.pais = rancho;
        }

        public bool Insertar()
        {
            bool retValue = false;
            SqlConnection conexion = new SqlConnection(Properties.Settings.Default.Conexion);
            SqlCommand comando = new SqlCommand();

            comando.CommandText = "Insert into Televisores values ("+this.id+",'"+this.marca+"',"+this.precio+","+this.pulgadas+",'"+this.pais+"' )";
            comando.CommandType = System.Data.CommandType.Text;
            comando.Connection = conexion;
            
            try
            {
                conexion.Open();
                comando.ExecuteNonQuery();
                conexion.Close();
                retValue = true;
            }
            catch (System.Exception)
            {

                throw;
            }


            return retValue;
        }
    }
}
