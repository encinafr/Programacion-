﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AdminiostradorArchivos;
namespace TestEscritura
{
    class Program
    {
        static void Main(string[] args)
        {
            string cadena;
            string cadena2;
            string path;
            path = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);//me devuelve la direccion de dende voy a escribir o leer

            cadena2 = AppDomain.CurrentDomain.BaseDirectory;//Donde estas parado actualmente.
            if (AdministradorArchivos.Escribir(path + ".txt", "Hola miguel"))
            {
                Console.WriteLine("Archivo guardado");
                Console.ReadKey();
            }

            if (AdministradorArchivos.Leer(path + ".txt", out cadena))
          // if (AdministradorArchivos.Leer(cadena2+".txt", out cadena))
            {
                Console.WriteLine(cadena);
                Console.ReadKey();
            }
        }
    }
}
