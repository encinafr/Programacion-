﻿using System;
using System.IO;
namespace AdminiostradorArchivos
{
   public static class AdministradorArchivos
    {
        public static bool Escribir(string path, string cadena)
        {
            try
            {
               // StreamWriter sw = new StreamWriter(path, false);// con false sobreescribo el archivo

                //sw.WriteLine(this.ToString());

                //sw.Close();
                using (StreamWriter sw = new StreamWriter(path, false))
                {
                    sw.WriteLine(cadena);
                }
                return true;
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                return false;
            }
        }

        public static bool Leer(string path,out string cadena)
        {
            try
            {
                //StreamWriter sw = new StreamWriter(g, false);// con false sobreescribo el archivo

                //sw.WriteLine(this.ToString());

                //sw.Close();
                using (StreamReader sw = new StreamReader(path, false))
                {
                    cadena = sw.ReadToEnd();
                }
                return true;
            }
            catch (Exception e)
            {
                cadena = "No se pudo leer el archivo";
                Console.WriteLine(e.Message);
                Console.WriteLine(cadena);
                Console.ReadKey();
                return false;
            }
        }
    }
}
