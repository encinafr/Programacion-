﻿public delegate void actualizarNombrePorDelegado(string dato);
