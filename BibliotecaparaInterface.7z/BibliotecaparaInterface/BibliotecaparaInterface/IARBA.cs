﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BibliotecaparaInterface
{
    public interface IARBA
    {
        double CalcularImpuesto();
    }
}
