﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BibliotecaparaInterface
{
   public class Deportivo: Auto, IAFIP,IARBA
    {
        protected int _caballoDeFuerza;

        public double Prop { get => throw new NotImplementedException(); set => throw new NotImplementedException(); }

        public Deportivo(double precio, string patente, int hp) : base(precio, patente)
        {
            this._caballoDeFuerza = hp;
        }

        double IAFIP.CalcularImpuesto()
        {
            return this._precio * 28 / 100;
        }


        public override void MostrarPrecio()
        {
            Console.WriteLine("El precio es {0}", this._precio);
        }

        double IARBA.CalcularImpuesto()
        {
            return this._precio * 23 / 100;
        }
    }
}
