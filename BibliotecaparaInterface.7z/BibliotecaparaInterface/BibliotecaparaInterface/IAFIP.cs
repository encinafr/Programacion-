﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BibliotecaparaInterface
{
    public interface IAFIP
    {
        double CalcularImpuesto();

       double Prop { get; set; }
    }
}
