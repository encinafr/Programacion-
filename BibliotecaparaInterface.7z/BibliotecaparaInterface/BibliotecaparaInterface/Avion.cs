﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BibliotecaparaInterface
{
   public class Avion : Vehiculo, IAFIP,IARBA
    {
        protected double _velovidadMaxima;

        public double Prop { get => throw new NotImplementedException(); set => throw new NotImplementedException(); }

        public Avion(double precio, double velMax) : base(precio)
        {
            this._velovidadMaxima = velMax;
        }

        double IAFIP.CalcularImpuesto()
        {
            return this._precio * 33 / 100;
        }

        double IARBA.CalcularImpuesto()
        {
            return this._precio * 27 / 100;
        }
        public override void MostrarPrecio()
        {
            Console.WriteLine("El precio del avion es: {0}", this._precio);
        }
    }
}
