﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BibliotecaparaInterface
{
    public class Comercial: Avion,IARBA
    {
        protected int capacidadPasajeros;
        public Comercial(double precio, double velocidad, int capacidad) : base(precio, velocidad)
        {
            this.capacidadPasajeros = capacidad;
        }

        double IARBA.CalcularImpuesto()
        { return this._precio * 27 / 100; }
    }
}
