﻿using System;

namespace BibliotecaparaInterface
{
    public class Carreta : Vehiculo,IARBA
    {
        public Carreta(double precio) : base(precio)
        {

        }
        public override void MostrarPrecio()
        {
            Console.WriteLine("El precio de la Carreta es {0}", this._precio);
        }
        double IARBA.CalcularImpuesto()
        { return this._precio * 18 / 100; }
    }
}
