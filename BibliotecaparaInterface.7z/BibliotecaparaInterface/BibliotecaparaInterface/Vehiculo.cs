﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BibliotecaparaInterface
{
   public abstract class Vehiculo
    {
        protected Double _precio;

        public abstract void MostrarPrecio();

        public Vehiculo(double precio)
        {
            this._precio = precio;
        }
    }
}
