﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BibliotecaparaInterface
{
   public abstract class Auto : Vehiculo
    {
        protected string patente;

        public Auto(double precio, string patente) : base(precio)
        {
            this.patente = patente;
        }

        public void MostrarPatente()
        {
            Console.WriteLine(this.patente);
        }
    }
}
