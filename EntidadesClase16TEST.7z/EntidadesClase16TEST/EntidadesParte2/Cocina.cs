﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;

namespace EntidadesParte2
{
   public class Cocina
    {
        protected int _codigo;
        protected bool _esIndustrial;
        protected double _precio;

        public int Codigo
        {
            get
            {
                return this._codigo;
            }
        }

        public bool EsIndustrial
        {
            get
            {
                return this._esIndustrial;
            }
        }

        public double Precio 
        {
            get
            {
                return this._precio;
            }
        }

        public Cocina(int codigo,double precio, bool esIsduntrial)
        {
            this._codigo = codigo;
            this._esIndustrial = esIsduntrial;
            this._precio = precio;

        }

        public override bool Equals(object obj)
        {
            Boolean retorno = false;

            if (obj is Cocina)
            {
                if (this == ((Cocina)obj))
                {
                    retorno = true;
                }
            }
            return retorno;
        }
        public static bool operator ==(Cocina a, Cocina b)

        {
            bool ret = false;
            if (a._codigo == b._codigo)
                ret = true;

            return ret;
        }

        public static bool operator !=(Cocina a, Cocina b)
        {
            return !(a == b);

        }

        public override string ToString()
        {
            return string.Format("\nCodigo:" + this._codigo + "  - Precio " + this._precio  + " - Es Industrial? "+ this._esIndustrial);
        }

        

    }
}
