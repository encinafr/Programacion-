﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EntidadesParte2
{
    public class Deposito<T>
    {
        protected Int32 _capacidadMaxima;
        protected List<T> _lista;

        public Deposito(int capacidad)
        {
             this._lista = new List<T>(capacidad);
            //this._lista = default(List<T>);
            this._capacidadMaxima = capacidad;
        }

        private Int32 GetIndice(T a)
        {
            int ret = -1;
            this._lista.IndexOf(a);
            return ret;
        }

        public Boolean Agregar(T a)
        {
            Boolean retorno = false;

            if (this._capacidadMaxima > this._lista.Count)
            {
                this._lista.Add(a);
                retorno = true;
            }

            return retorno;
        }

        public static Boolean operator +(Deposito<T> d, T a)
        {
            Boolean retorno = false;
            retorno = d.Agregar(a);
            return retorno;
        }

        public Boolean Remover(T a)
        {
            Boolean retorno = false;
            Int32 indexAuto = this.GetIndice(a);

            if (indexAuto != -1)
            {
                this._lista.RemoveAt(indexAuto);
                retorno = true;
            }

            return retorno;
        }

        public static Boolean operator -(Deposito<T> d, T a)
        {
            Boolean retorno = false;
            retorno = d.Remover(a);

            return retorno;
        }

        public override string ToString()
        {
            StringBuilder stringBuild = new StringBuilder();
            stringBuild.AppendFormat("Capacidad máxima: {0}\n", this._capacidadMaxima);
            stringBuild.AppendLine("Listado de Objetos:");

            foreach (T TA in this._lista)
            {
                stringBuild.AppendFormat("{0}", TA.ToString());
            }

            return stringBuild.ToString();
        }
    }
}
