﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
namespace EntidadesParte2
{
    public class DespositoDeCocinas
    {
        protected int _capacidadMaxima;
        protected List<Cocina> _lista;

        public DespositoDeCocinas(int capacidad)
        {
            this._lista = new List<Cocina>(capacidad);
            this._capacidadMaxima = capacidad;
        }

        private Int32 GetIndice(Cocina a)
        {
            return this._lista.IndexOf(a);
        }

        public Boolean Agregar(Cocina a)
        {
            Boolean retorno = false;

            if (this._capacidadMaxima > this._lista.Count)
            {
                this._lista.Add(a);
                retorno = true;
            }

            return retorno;
        }

        public static Boolean operator +(DespositoDeCocinas d, Cocina a)
        {
            Boolean retorno = false;
            retorno = d.Agregar(a);
            return retorno;
        }

        public Boolean Remover(Cocina a)
        {
            Boolean retorno = false;
            Int32 indexAuto = this.GetIndice(a);

            if (indexAuto != -1)
            {
                this._lista.RemoveAt(indexAuto);
                retorno = true;
            }

            return retorno;
        }

        public static Boolean operator -(DespositoDeCocinas d, Cocina a)
        {
            Boolean retorno = false;
            retorno = d.Remover(a);

            return retorno;
        }

        public override string ToString()
        {
            StringBuilder stringBuild = new StringBuilder();
            stringBuild.AppendFormat("Capacidad máxima: {0}\n", this._capacidadMaxima);
            stringBuild.AppendLine("Listado de Autos:");

            foreach (Cocina cocinaA in this._lista)
            {
                stringBuild.AppendFormat("\n{0}", cocinaA.ToString());
            }

            return stringBuild.ToString();
        }
        public bool Guardar(string g)
        {
            try
            {
                //StreamWriter sw = new StreamWriter(g, false);// con false sobreescribo el archivo

                //sw.WriteLine(this.ToString());

                //sw.Close();
                using (StreamWriter sw = new StreamWriter(g, false))
                {
                    sw.WriteLine(this.ToString());
                }
                return true;
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                return false;
            }
        }
            public bool Recuperar(string A)
            {
                try
                {
                    //StreamWriter sw = new StreamWriter(g, false);// con false sobreescribo el archivo

                    //sw.WriteLine(this.ToString());

                    //sw.Close();
                    using (StreamReader sw = new StreamReader(A, false))
                    {
                        Console.WriteLine(sw.ReadToEnd());
                    }
                    return true;
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.Message);
                    return false;
                }

            }

        
    }
}
