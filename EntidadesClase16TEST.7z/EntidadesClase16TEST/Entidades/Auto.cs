﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Entidades
{
    public class Auto
    {
        protected string _color;
        protected string _marca;

        public string Color
        {

            get {
                return _color;
               }
        }

        public string Marca
        {

            get
            {
                return _marca;
            }
        }

        public Auto(string color, string marca)
        {
            this._color = color;
            this._marca = marca;
        }

        public override bool Equals(object obj)
        {
            Boolean retorno = false;

            if (obj is Auto)
            {
                if (this == ((Auto)obj))
                { retorno = true; }
            }
            return retorno;
        }

        public static bool operator ==(Auto a, Auto b)

        {
            bool ret = false;
            if (a._marca == b._marca && a._color == b._color)
                ret = true;

            return ret;
        }

        public static bool operator !=(Auto a, Auto b)
        {
            return !(a == b);

        }

        public override string ToString()
        {
            return string.Format("\nColor:" + this._color + " "+ " Marca: " + this._marca);
        }

    }
}
