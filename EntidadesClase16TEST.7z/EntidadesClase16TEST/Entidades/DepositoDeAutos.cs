﻿using System;
using System.Collections.Generic;
using System.Text;
using Entidades;
using System.IO;
namespace Entidades
{
   public class DepositoDeAutos
    {
        protected Int32 _capacidadMaxima;
        protected List<Auto> _lista;

        public DepositoDeAutos(int capacidad)
        {
            this._lista = new List<Auto>(capacidad);
            this._capacidadMaxima = capacidad;
        }

        private Int32 GetIndice(Auto a)
        { return this._lista.IndexOf(a); }

        public Boolean Agregar(Auto a)
        {
            Boolean retorno = false;

            if (this._capacidadMaxima > this._lista.Count)
            {
                this._lista.Add(a);
                retorno = true;
            }

            return retorno;
        }

        public static Boolean operator +(DepositoDeAutos d, Auto a)
        {
            Boolean retorno = false;
            retorno = d.Agregar(a);
            return retorno;
        }

        public Boolean Remover(Auto a)
        {
            Boolean retorno = false;
            Int32 indexAuto = this.GetIndice(a);

            if (indexAuto != -1)
            {
                this._lista.RemoveAt(indexAuto);
                retorno = true;
            }

            return retorno;
        }

        public static Boolean operator -(DepositoDeAutos d, Auto a)
        {
            Boolean retorno = false;
            retorno = d.Remover(a);

            return retorno;
        }

        public override string ToString()
        {
            StringBuilder stringBuild = new StringBuilder();
            stringBuild.AppendFormat("Capacidad máxima: {0}\n", this._capacidadMaxima);
            stringBuild.AppendLine("Listado de Autos:");

            foreach (Auto autoA in this._lista)
            {
                stringBuild.AppendFormat("{0}", autoA.ToString());
            }

            return stringBuild.ToString();
        }
       

    }
}
